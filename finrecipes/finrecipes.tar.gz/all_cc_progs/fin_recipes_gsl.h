

double heston_call_option_price(const double& S, const double& K, const double& r,  const double& v, const double& tau,
				const double& rho,  const double& kappa,  const double& lambda, const double& theta, const double& sigma);
