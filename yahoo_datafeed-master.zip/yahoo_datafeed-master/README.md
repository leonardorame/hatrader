UDF-compatible Yahoo datafeed
==============

This repository contains a sample implementation of server-side UDF-compatible data source.
Use nodejs to launch yahoo.js